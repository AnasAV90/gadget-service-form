let formData = {};
    let secondCards = {
      "mobile": "<h2 class='heading'>Which type of<br> Mobile is it?</h2><ul class='optionDiv'><li class='optionList' onclick='secondCardSelect(event)'><img src='https://res.cloudinary.com/dz9tay9eg/image/upload/v1662998775/website/devices/Mobile_m103pw_tqtf8v.png' alt=''><input id='iphone' type='radio' name='type' field='iphone' value='iphone' array='iphone'><label for='iphone'>Iphone</label></li><li class='optionList' onclick='secondCardSelect(event)'><img src='https://res.cloudinary.com/dz9tay9eg/image/upload/v1662998774/website/devices/81-fNmQqlLL._AC_SX522__va66zm_tlwsuy.jpg' alt=''><input id='android' type='radio' name='type' field='android' value='android' array='android'><label for='android'>Android</label></li></ul>",
      "laptop": "<h2 class='heading'>Which type of<br> Laptop is it?</h2><ul class='optionDiv'><li class='optionList' onclick='secondCardSelect(event)'><img src='https://res.cloudinary.com/dz9tay9eg/image/upload/v1662998775/website/devices/Laptop_mmjsn8_uzxy96.png' alt=''><input id='mac' type='radio' name='type' field='mac' value='mac' array='mac'><label for='mac'>Mac</label></li><li class='optionList' onclick='secondCardSelect(event)' ><img src='https://res.cloudinary.com/dz9tay9eg/image/upload/v1662998775/website/devices/81KoSSAwH2L._SL1500__oh8sja_nef4ea.jpg' alt=''>\n<input id='windows' type='radio' name='type' field='windows' value='windows' array='windows'><label for='windows'>Windows</label></li></ul>"
    };
    let checkFormSubmitted= false;
    $(document).ready(function () {
        $(".contactForm").on('submit', function (e) {
        e.preventDefault();
         if(checkFormSubmitted){
          return false;
      }
        $("[inputDiv]").each(function(){
            formData[$(this).attr("id")] = $(this).val();
        });
        $(".loader").css('display', 'block');
        checkFormSubmitted = true;
        //alert(ajaxurl);
        //alert(thankyou);
        $.ajax({
          type: "post",
          url: ajaxurl,
          data: formData,
          validation: function () {
            $(".thanks").text('Please enter correct data').css('color', 'red');
             checkFormSubmitted = false;
          },
          success: function (data) {
            $("#contactSubmit").hide();
            alert("Success");
            location.href = thankyou;
          }
        });
      });
    });

    $(document).ready(function () {
      $('.mobile-valid').on('keyup', function (e) {
        var data = $(this).val();
        if (data.length > 17) {
          data = data.slice(0, 16);
          $(this).val(data);
        }
        if (!Number.isInteger(data)) {
          var newVal = parseInt(data);
          if (newVal >= 0) {
            $(this).val(newVal);
          } else {
            $(this).val('');
          }
        }
      });
    });

    /* function for sliding cards*/
    function sideScrollCards(elementWrapper, cardCalss, direction, increment, animationFunction) {
      increment = increment || 1;
      var slideIndex = elementWrapper + 'Index';
      window[slideIndex] = (typeof window[slideIndex] != 'undefined') ? window[slideIndex] : 0;
      var cardCalssList = document.getElementsByClassName(cardCalss);
      var firstCard = cardCalssList[0];
      var wrapperDiv = document.getElementById(elementWrapper);
      wrapperDiv.style.transition = 'transform 0.6s ease';
      var cardNos = cardCalssList.length;
      var cardWidth = firstCard.offsetWidth;
      var distanceToTransalte = 0;
      var wrapperWidth = wrapperDiv.offsetWidth;
      var cardStyle = firstCard.currentStyle || window.getComputedStyle(firstCard);
      var wrapperStyle = wrapperDiv.currentStyle || window.getComputedStyle(wrapperDiv);
      var cardOuterWidth = cardWidth + parseFloat(cardStyle.marginRight) + parseFloat(cardStyle.marginLeft);
      var wrapperInnerWidth = wrapperWidth - (parseFloat(wrapperStyle.paddingRight) + parseFloat(wrapperStyle
        .paddingLeft));
      var totalWidthOfCards = cardOuterWidth * cardNos;
      if (direction === 'prev') {
        window[slideIndex] = (window[slideIndex] > 0) ? window[slideIndex] - increment : 0;
      } else if (direction === 'next') {
        window[slideIndex] = (window[slideIndex] <= cardNos) ? window[slideIndex] + increment : 0;
      }
      console.log('fnindex : ' + window[slideIndex]);
      //window[slideIndex] = (window[slideIndex] > (cardNos - 1)) ? 0 : window[slideIndex];
      distanceToTransalte = window[slideIndex] * cardOuterWidth;
      if (distanceToTransalte > ((totalWidthOfCards - wrapperInnerWidth) + (cardOuterWidth * increment))) {
        window[slideIndex] = 0;
        distanceToTransalte = 0;
      } else if (distanceToTransalte > (totalWidthOfCards - wrapperInnerWidth)) {
        distanceToTransalte = totalWidthOfCards - wrapperInnerWidth;
        window[slideIndex] = cardNos;
      }
      distanceToTransalte = (distanceToTransalte === 0) ? 0 : '-' + distanceToTransalte;
      wrapperDiv.style.transform = 'translateX(' + distanceToTransalte + 'px)';
      if (animationFunction) {
        animationFunction();
      }
      let slides = $("#" + elementWrapper + ' .slide');
      slides.css("height", '0');
      slides.css("opacity", '0');
      const activeSlide = "#" + elementWrapper + ' .slide:nth-child(' + (window[slideIndex] + 1) + ')';

      console.log(activeSlide);
      $(activeSlide).css("height", 'auto');
      $(activeSlide).css("opacity", '1');
    }
    
    $(document).ready(function () {
      $("[device]").on("click", function (e) {
        e.preventDefault();
        $("[slide='2']").remove();
        let seconCardContainer = '<div id="mobileDevices" class="slide section secondCard" slide="2">';
        let elem = $(this);
        const device = elem.attr("device");
        formData["device"] = device;
        if (device === "laptop" || device === "mobile") {
          seconCardContainer += secondCards[device];
          seconCardContainer += `<a onclick="sideScrollCards('wallSlideWrapper', 'slide', 'prev');" class="btn  btn5 xlBtn nextBtn">Back</a>`;
           seconCardContainer += '</div>';
          $("[slide ='1']").after(seconCardContainer);
        }
        sideScrollCards('wallSlideWrapper', 'slide', 'next');
      });
    });

    function secondCardSelect(event) {
      event.preventDefault();
      let elem = $(event.target);
      let value = $("[name='type']").val();
      formData["type"] = value;
      console.log(formData);
      sideScrollCards('wallSlideWrapper', 'slide', 'next');
    }